<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Administracija extends Backend_Controller{
    
    function __construct() {
        parent::__construct();
        if($this->session->userdata("korisnik_uloga_id") != '1'){
            redirect(base_url('/'));
        }
        $this->load->model('AdministracijaModel','a');
    }
    public function index(){
        $views = array('administracija/administracija');
        $title = array('title'=>'Administracija');
        
        $tableTemplate = array('table_open' => '<table class="table table-hover">' );
        $this->table->set_template($tableTemplate);
        $this->table->set_heading('#', 'Ime', 'Email', 'Uloga','Promeni','Obrisi');
        $korisnici = $this->a->get_korisnici();
        $result = array();
        foreach($korisnici AS $korisnik){
            array_push($korisnik,"<a href='promeniKorisnika/{$korisnik['id_korisnika']}'>Promeni</a>");
            array_push($korisnik,"<a href='obrisiKorisnika/{$korisnik['id_korisnika']}'>Obrisi</a>");
            array_push($result,$korisnik);
        }
        
        
        $title['korisnici'] = $this->table->generate($result);
        $this->load_view($views,$title);
    }
    public function obrisiKorisnika(){
        $id = $this->uri->segment('2');
        $upit = $this->a->delete_korisnici($id);
        if($upit){
            redirect(base_url('administracija'));

        }
        echo "Hoce obrise korisnika sa id " . $this->uri->segment('2');
    }
    public function promeniKorisnika(){
        $dataView = array();
        $dataView['success_message'] = '';
        $dataView['error_message'] = '';
        if($this->input->post()){
            $email = $this->input->post('email');
            $ime = $this->input->post('ime');
            $id = $this->input->post('id');
            // update data
            $data = array(
                'korisnicko_ime' => $ime,
                'mail_korisnika' => $email
            );
            $update = $this->a->edit_korisnici($id,$data);
            if($update){
                $dataView['success_message'] = 'Uspesno ste izmenili korisnika';
            }else{
                $dataView['error_message'] = 'Doslo je do greske';
            }
        }
        $views = array('administracija/administracija');
        $dataView['title'] = 'Administracija';
        $korisnici = $this->a->get_korisnik($this->uri->segment('2'));
        var_dump($this->uri->segment('2'));
        $dataView['podaci_korisnika'] = array(
            'labels' => array(
                'id','ime','email','uloga'
            ),
            'data' => $korisnici
        );
        $this->load_view($views,$dataView);
    }
    
    public function ubaciKorisnika(){
        $ime = $this->input->post('tbImeInsert');
        $sifra = $this->input->post(('tbPassInsert'));
        $email = $this->input->post('tbEmailInsert');
        $id_uloge = $this->input->post('tbUloga');
        
        $uneseno = $this->a->insert_korisnici($ime,md5($sifra),$email,$id_uloge);
        if($uneseno){
            redirect(base_url('administracija'));
        }
    }
    
    
    public function prikaziMeni(){
        
        $views = array('administracija/menuView');
        $title = array('title'=>'meni');
        $this->load_view($views,$title);
        
    }
    
    public function prikaziPromo(){
        $views = array('administracija/promoView');
        $title = array('title'=>'Promo');
        
        
        
        
        $tableTemplate = array('table_open' => '<table class="table table-hover">' );
        $this->table->set_template($tableTemplate);
        $this->table->set_heading('#', 'nazivPromo', 'naziv smestaja' ,'Pozicija', 'Dadum dodavanja','Datum isteka','Promeni','Obrisi');
        $promo= $this->a->get_promo();
        
        $rezultat=array();
        
        foreach($promo AS $pro){
            array_push($pro,"<a href='promeniPromo/{$pro['id_promo']}'>Promeni</a>");
            array_push($pro,"<a href='obrisiKorisnika/{$pro['id_promo']}'>Obrisi</a>");
            array_push($rezultat,$pro);
        }
        
        
        $title['promo']= $this->table->generate($rezultat);
        
        
        
        $this->load_view($views,$title);
        
    }
    
    public function promeniPromo(){
        $dataView = array();
        $dataView['success_message'] = '';
        $dataView['error_message'] = '';
        
    
    $views = array('administracija/promoView');
        $dataView['title'] = 'Promocije';
        $promocije = $this->a->get_promocija($this->uri->segment('3'));
        
        $dataView['podaci_promo'] = array(
            'labels' => array(
                'id','ime','email','uloga','datums','datumi'
            ),
            'data' => $promocije
        );
        $this->load_view($views,$dataView);
    }
    
    
    
    
}