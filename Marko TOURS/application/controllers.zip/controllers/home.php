<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Home extends Frontend_Controller{
    private $data = array();
    function __construct() {
        parent::__construct();
        $this->load->model("Meni",'m');
        $this->data['menu'] = $this->m->dohvatiMeni(1);
    }
    public function index(){
        $centar = array('centar_levo','centar_desno');
        $this->load->model("Meni",'m');
        $this->data['title']='Marko TOURS - Pocetna stranica';
        $this->load_view($centar, $this->data);
    }
    public function login(){
        if($this->session->userdata('korisnik_uloga_id')){
            redirect(base_url('/'));
        }
        $centar = array('login');
		$this->load->library('form_validation');
        $this->data['title']='Marko Tours - Login';
        $this->form_validation->set_rules('tbUser', 'Username', 'required' );
        $this->form_validation->set_rules('tbPass', 'Password', 'required');
        $this->form_validation->set_message('required', '%s field is required');
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		if ($this->form_validation->run() != FALSE)
        {
            $this->load->model('korisnici','k');
            $user = $this->input->post('tbUser');
            $pass = $this->input->post('tbPass');
            $proveraLogin = $this->k->dohvatiKorisnike($user,md5($pass));
            if($proveraLogin != false){
                // success login redirect here
                $this->session->set_userdata('korisnik_ime',$proveraLogin['korisnicko_ime']);
                $this->session->set_userdata('korisnik_email',$proveraLogin['mail_korisnika']);
                $this->session->set_userdata('korisnik_uloga_id',$proveraLogin['id_uloge']);
                if($this->session->userdata("korisnik_uloga_id") == '1'){
                    redirect(base_url('administracija'));
                }else{
                    redirect(base_url('/'));
                }
            }else{
                $this->data['no_user'] = "<div class='error'>Ne postoji korisnik sa unetim parametrima!</div>";
            }
        }
        else
        {
        }
        $this->load_view($centar, $this->data);
    }
    public function about(){
        $view = array('onama');
        $this->data['title'] = "O nama";
        $this->load_view($view,$this->data);
    }
}

?>