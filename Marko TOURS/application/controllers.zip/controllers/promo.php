<?php
class promo extends Frontend_Controller
{
    function __construct()
    {
        parent::__construct();
    }

    public function index()
    {

        $centar = array('centar_levo','promo');
        $this->load->model("Meni",'m');
        $this->load->model("promoModel",'pm');
        $data['title']='Marko TOURS - Pocetna stranica';
        $data['menu'] = $this->m->dohvatiMeni(1);
        $data['ponude'] = $this->pm->dohvatiPonude($this->uri->segment('2'));
        $this->load_view($centar, $data);

    }
}