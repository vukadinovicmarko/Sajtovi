<?php
    if(!$this->session->userdata('user')){?>
        <div class='logo-login marginTop625p col-xs-8 col-xs-offset-2 col-sm-6 col-sm-offset-3 col-md-5 col-md-offset-1 col-lg-4 col-lg-offset-2 hidden-xs'>
            <img src='<?php print base_url(); ?>assets/images/slika01.png' class='img-circle img-responsive'/>
        </div>
<div class='col-xs-8 col-xs-offset-2 col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-0 col-lg-6'>
<div class='login_div col-sm-12 col-lg-6 col-lg-offset-0'>
    <?php
        if(isset($no_user)){
            echo $no_user;
        }
    ?>
    <legend class='green'>Login</legend>
    <?php echo form_open('home/login'); ?>
    <?php
    $username=array
    (
        'name' => 'tbUser',
        'id' => 'tbUser',
        'placeholder' => 'Unesite ovde vase korisnicko ime',
        'class' => 'form-control',
        'value' => set_value('tbUser')
    );
    $pass = array
    (
        'name' => 'tbPass',
        'id' => 'tbPass',
        'placeholder' => 'Ovde ukucajte Vasu sifru',
        'class' => 'form-control'
    );
    $btnLogin = array
    (
        'type'=>'submit',
        'name'=>'btnLogin',
        'id'=>'btnLogin-1',
        'class' => 'btn btn-default text-center col-lg-12 marginTop20',
        'content'=>'Ulogujte se',
        'align'=>'right',
        'onClick' => 'login()'
    );
    
    echo '<label for="tbUser">korisnicko ime</label> '
        .form_input($username).
        form_error('tbUser').
        '<label for="tbPass">Sifra</label>'
        . form_password($pass).
        form_error('tbPass').
        form_button($btnLogin)
        . "<div class='clearfix'></div><h5><a href='#' class='show_registration' onClick=''>Napravite nalog</a></h5>";
    echo form_close();
?>
    </fieldset>
</div>
</div>

<div class='reg_div col-sm-12 col-lg-6 col-lg-offset-0'>
<div class='reg_div_okvir col-lg-6 col-lg-offset-0'>
    <legend class='red'>Register</legend>
    <?php
        
        $usernameReg=array
        (
            'name' => 'reg_tbUser',
            'id' => 'reg_tbUser',
            'placeholder' => 'Unesite ovde vase korisnicko ime',
            'class' => 'form-control ',
            'value' => set_value('reg_tbUser')
        );
        $email=array
        (
            'name' => 'reg_tbEmail',
            'id' => 'reg_tbEmail',
            'placeholder' => 'Unesite ovde vase email',
            'class' => 'form-control validate-email ',
            'value' => set_value('reg_tbEmail')
        );
        $passReg = array
        (
            'name' => 'reg_tbPass',
            'id' => 'reg_tbPass',
            'placeholder' => 'Ovde ukucajte Vasu sifru',
            'class' => 'form-control'
        );
        $passReg2 = array
        (
            'name' => 'reg_tbPass2',
            'id' => 'reg_tbPass2',
            'placeholder' => 'Ovde ponovite Vasu sifru',
            'class' => 'form-control'
        );
        $btnReg = array
        (
            'type'=>'submit',
            'name'=>'reg_btnLogin',
            'id'=>'reg_btnLogin',
            'class' => 'btn btn-default text-center col-lg-12 marginTop20',
            'content'=>'Kreirajte nalog',
            'align'=>'right'
        );
        echo form_open("home/registracija");
        
        echo '<label for="reg_tbUser">Korisničko ime</label>';
        echo form_input($usernameReg);
        echo '<label for="reg_tbEmail">Email</label>';
        echo form_input($email);
        echo '<label for="reg_tbPass">Šifra</label>';
        echo form_password($passReg);
        echo '<label for="reg_tbPass2">Ponovite šifru</label>';
        echo form_password($passReg2);
        echo form_button($btnReg);
    echo "<div class='clearfix'></div><h5><a href='#' class='show_login' onClick=''>Ulogujte se</a></h5>";
        echo form_close();

                        
    ?>
</div>
    </div>

<?php
    }

?>