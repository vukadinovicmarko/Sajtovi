<div class="centar_levo_ostalo col-xs-12 col-sm-4 col-md-4 col-lg-3 col-lg-offset-2 marginTop5p">
    
    
    <img src="<?php base_url(); ?>../assets/images/autor/slika01.jpg" class="img-responsive img-circle" />
    
</div>

<div class="centar_desno_ostalo col-xs-12 col-sm-8 col-md-8 col-lg-5 marginTop5p">
    <h2 class="red">Marko Vukadinovic</h2>
    <br>    
    <p class="green">Student sam trece godine Visoke ICT skole, smer Internet Tehnologije, izabrao sam modul Web Programiranje.</p>
    <p>Moji prethodni radovi :</p>
    <p><a href="http://markovukadinovic.byethost15.com/">Pekara Marko - kurs "Web dizajn"</a></p>
    <p><a href="http://markohotel.byethost8.com/index.html">Hotel Marko - kurs "Web programiranje"</a></p>
    
    
</div>