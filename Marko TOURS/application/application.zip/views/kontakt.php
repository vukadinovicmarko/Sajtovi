<div class="centar_levo_ostalo col-xs-12 col-sm-4 col-md-4 col-lg-3 col-lg-offset-2 marginTop5p">
    
    <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1415.183485172295!2d20.4836735!3d44.8140881!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475a7abd53a12043%3A0x4a6a07ad64d80bee!2sZdravka+%C4%8Celara!5e0!3m2!1sen!2srs!4v1458087600239" frameborder="0" style="border:0" allowfullscreen></iframe>
    
</div>

<div class="centar_desno_ostalo col-xs-12 col-sm-8 col-md-8 col-lg-5 marginTop5p">
    
    <?php
        echo form_open();
        
        echo $table;
        
        echo form_close();
        
        
    
    ?>
    
    
</div>