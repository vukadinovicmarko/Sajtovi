<?php

    foreach($ponude AS $ponuda){
        echo "<fieldset>
            <h2>{$ponuda['naziv']}</h2>
            {$ponuda['opis']}




        </fieldset>";
    }
?>