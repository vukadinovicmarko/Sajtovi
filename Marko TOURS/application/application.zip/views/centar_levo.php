<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<div  class="centar_levo col-xs-12 col-sm-4 col-md-4 col-lg-3 col-lg-offset-2 marginTop5p">
    <div class="istaknuto">

        <ul class="nav nav-tabs" role="tablist">
            <?php
            $i = 0;
            foreach($promo AS $p){
                if($i==0){
                    $class = 'active';
                }else{
                    $class = '';
                }
                $i++;
                echo '<li role="presentation" class="'.$class.'"><a href="#istaknuto_'.$p['id_promo'].'" aria-controls="home" role="tab" data-toggle="tab">'.$p['naziv_promo'].'</a></li>';
            }
            echo "</ul><div class='tab-content'>";
                $j = 0;
                foreach($promo AS $p){
                    if($j==0){
                        $class = 'active';
                    }else{
                        $class = '';
                    }
                    $j++;
                    echo '<div role="tabpanel" class="tab-pane fade in ' . $class . '" id="istaknuto_'.$p['id_promo'].'">';
                    echo "<table class='tabela' class='tabela' cellspacing='0'>";
                    foreach($p['smestaji'] AS $sm){
                        echo"<tr >
                            <td>{$sm['naziv']}</td>";
                        if($sm['popust']){
                            echo "<td align='right' class='red'>{$sm['popust']}%</td>";
                        }else{
                            echo "<td align='right' class='red'>{$sm['cena']} Eur</td>";
                        }
                        echo "</tr>";
                    }
                    echo "</table>
                        </div>
                    ";
                }
            echo "</div>";
            ?>
        </ul>

    </div>
    </br>
    <div class="istaknuto">
        <ul class="ul_istaknuto2">
            <a href="#"><div class='slika'></div></a>
        </ul>
        <div class="istaknuto_sadrzaj">
        </div>  
    </div>
</div>