<?php
if(isset($promo)){
            echo "<h3 class='green'>Prikaz promocija</h3>";
            ?>
                <div class="row col-lg-6 col-md-6 col-sm-6">
                    <button type="button" class="btn btn-default showAdd">Dodaj <?php echo $title;?></button>
                    <div class="clearfix"></div>
                    <br/>
                    <div class="row col-lg-12 col-md-12 col-sm-12 hiddenDiv">
                        <?php
                        echo $forma;
                        ?>
                    </div>
                </div>
            <?php
            echo $promo;
        }

        if(isset($podaci_promo)){
            $i=0;
             
            echo form_open();
            foreach($podaci_promo['data'] AS $podatak){
                
                echo "
                <div class='form-group'>
                    <label for='promena_$i' class='col-sm-2 control-label text-right'>
                        {$podaci_promo['labels'][$i]}
                    </label>
                    <div class='col-sm-6'>
                        <input id='promena_$i' name='{$podaci_promo['labels'][$i]}' class='form-control' type='text' ";
                        if($i == 0){
                            echo " readonly ";
                        }
                        foreach($podatak as $p){
                        echo " value='$p'/>";
                        }
                            
                    echo "</div>
                <div class='clearfix'></div>
                </div>
                ";
                $i++;
            }
            
           
            
            echo "<div class='form-group col-sm-8 text-right'>
                    <input type='submit' value='Promeni'/>
                </div>";
            
            echo form_close();
        }
        
?>

</div>