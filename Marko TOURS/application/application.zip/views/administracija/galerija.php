<?php
echo "<h3 class='green'>Prikaz $title</h3>";
?>
<div class="row">
    <button type="button" class="btn btn-default">Dodaj <?php echo $title;?></button>
</div>

</div>
