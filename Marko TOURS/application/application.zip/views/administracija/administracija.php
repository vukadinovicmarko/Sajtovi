 <!--<h3 class="red">Ubacivanje korisnika</h3>-->
    <?php
//        echo form_open('administracija/ubaciKorisnika');
//        
//            $ime=array
//        (
//            'name' => 'tbImeInsert',
//            'id' => 'tbImeInsert',
//            'placeholder' => 'Unesite ovde ime',
//            
//        );
//        $password = array
//        (
//            'name' => 'tbPassInsert',
//            'id' => 'tbPassInsert',
//            'placeholder' => 'Ovde ukucajte Sifru',
//        );
//        $email = array
//        (
//            'name' => 'tbEmailInsert',
//            'id' => 'tbEmailInsert',
//            'placeholder' => 'Ovde ukucajte email',
//            
//        );
//        
//        $uloga = array
//        (
//            'name' => 'tbUloga',
//            'id' => 'tbUloga',
//            'placeholder' => 'Ovde ukucajte id Uloge',
//            
//        );
//        $btnInsert = array
//        (
//            'type'=>'submit',
//            'name'=>'btnInsert',
//            'id'=>'btnInsert',
//            'class' => 'btn btn-default  col-lg-3 col-lg-offset-0 marginTop20',
//            'content'=>'Ubacite korisnika',
//            'align'=>'right',
//            'onClick' => 'ubaciKorisnika()'
//        );
//        $celija = array('data' => form_button($btnInsert), 'colspan' => '2');
//        $this->table->add_row(array('<label for="tbImeInsert">Ime</label>',form_input($ime)));
//        $this->table->add_row(array('<label for="tbPassInsert">Sifra</label>',form_input($password)));
//        $this->table->add_row(array('<label for="tbEmailInsert">E-mail</label>',form_input($email)));
//        $this->table->add_row(array('<label for="tbUloga">ID Uloge</label>',form_input($uloga)));
//        $this->table->add_row(array($celija));
//        
//        echo $this->table->generate();
//        echo form_close();
//    
//
        if(isset($korisnici)){
            echo "<h3 class='green'>Prikaz korisnika</h3>";
            echo $korisnici;
        }

        if(isset($podaci_korisnika)){
            $i=0;
             
            echo form_open();
            foreach($podaci_korisnika['data'] AS $podatak){
                var_dump($podatak);
                echo "
                <div class='form-group'>
                    <label for='promena_$i' class='col-sm-2 control-label text-right'>
                        {$podaci_korisnika['labels'][$i]}
                    </label>
                    <div class='col-sm-6'>
                        <input id='promena_$i' name='{$podaci_korisnika['labels'][$i]}' class='form-control' type='text' ";
                        if($i == 0 || $i == 3){
                            echo " readonly ";
                        }
                        
                        echo " value='$podatak'/>
                            
                    </div>
                <div class='clearfix'></div>
                </div>
                ";
                $i++;
            }
            
            
            echo "<div class='form-group col-sm-8 text-right'>
                    <input type='submit' value='Promeni'/>
                </div>";
            echo form_close();
            
        }
        
        
    ?>
</div>

