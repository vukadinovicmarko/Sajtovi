<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="ocisti"></div>
</div>

</div>

<div id="footer">
    <div class="container">
    Powered by : Marko Vukadinovic
    <a href="https://www.facebook.com/m4r3ja" target="_blank"><img src="/assets/images/autor/facebook.png" width="50" height="50"/></a>
    <a href="http://rs.linkedin.com/in/markovukadinovic" target="_blank"><img src="/assets/images/autor/linkedin.png" width="50" height="50" /></a>
    </div>
</div>
<?php

?>
    
    </body>
</html>