<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<div id="centar_desno" class="col-xs-12 col-sm-8 col-md-8 col-lg-5 marginTop5p">
<div class="home_slideshow">
            
            
                <h3 ><a href="#" >Rezervisite putovanje</a></h3>
                
                <img src="assets/images/homePozadina/slika01-720.jpg" class="img-responsive"/>
            
</div>

</div>