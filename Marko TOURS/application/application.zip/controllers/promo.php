<?php
class promo extends Frontend_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model("Meni",'m');
        $this->data['menu'] = array();
        foreach( $this->m->dohvatiGlavniMeni() AS $glavniMeniLink){
            $idMeni = $glavniMeniLink['id_meni'];
            $meniNiz = array();
            $meniNiz['naziv_menija'] = $glavniMeniLink['naziv_menija'];
            $meniNiz['linkovi'] = array();
            foreach($this->m->dohvatiLinkoveOdMenija($idMeni) AS $linkovi){
                $linkoviNiz = array();
                $linkoviNiz['id'] = $linkovi['id_link'];
                $linkoviNiz['naziv'] = $linkovi['naziv_link'];
                array_push( $meniNiz['linkovi'] ,$linkoviNiz);
            }
            array_push($this->data['menu'],$meniNiz);
        }
    }

    public function index()
    {

        $centar = array('centar_levo','promo');
        $this->load->model("Meni",'m');
        $this->load->model("promoModel",'pm');
        $this->data['title']='Marko TOURS - Pocetna stranica';
        $this->data['ponude'] = $this->pm->dohvatiPonude($this->uri->segment('2'));
        $istaknuto = $this->m->dohvatiIstaknuto();
        $promo = array();
        foreach($istaknuto AS $istaknuce){
            $niz = array();
            $niz['naziv_promo'] = $istaknuce['naziv_promo'];
            $niz['id_promo'] = $istaknuce['id_promo'];
            $niz['smestaji'] = array();
            foreach(json_decode($istaknuce['id_slobodni_smestaji']) AS $id) {
                $smestaji = $this->m->dohvatiSmestaje($id);
                foreach ($smestaji AS $smetaj) {
                    array_push($niz['smestaji'], array(
                        'naziv' => $smetaj['naziv'],
                        'cena' => $smetaj['cena_po_sobi'],
                        'popust' => $smetaj['popust']
                    ));
                }
            }
            array_push($promo,$niz);
        }
        $this->load->model('AdministracijaModel','a');
        $this->data['slike'] = $this->a->get_slike();
        $this->data['promo'] = $promo;
        $this->load_view($centar, $this->data);

    }
}